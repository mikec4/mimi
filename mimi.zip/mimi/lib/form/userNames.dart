import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/scheduler.dart' show timeDilation;
import 'package:flutter/services.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:mimi/mainPage/landingPage.dart';


class UserNames extends StatefulWidget {
  @override
  _UserNamesState createState() => _UserNamesState();
}

class _UserNamesState extends State<UserNames> with SingleTickerProviderStateMixin {
  bool _firstStatus = false;
  bool _lastStatus = false;

  GlobalKey<FormState> _formKey = new GlobalKey<FormState>();

  AnimationController _animationController;
  Animation<double> _animation;






  @override
  void initState() {
    super.initState();
    _animationController = new AnimationController(vsync: this,
        duration: Duration(milliseconds: 10000  ));

    _animationController.forward();

  }

  @override
  Widget build(BuildContext context) {

    return WillPopScope(
      onWillPop: _onBackPressed,
      child: Scaffold(
        floatingActionButton: _floatingButton(),
        floatingActionButtonAnimator: FloatingActionButtonAnimator.scaling,
        floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,
        body: SafeArea(
            child: SingleChildScrollView(
              reverse: true,
              child: Padding(
                padding: EdgeInsets.only(left: 40.0,right: 40.0,top: 150.0),
                child: Column(
                  children: <Widget>[
                    FlutterLogo(
                      size: 120.0,
                      colors: Colors.green,
                    ),
                    SizedBox(height: 20.0,),
                    _form(),
                    SizedBox(height: 20.0,),
                    Row(
                      children: <Widget>[
                        _emailTextField(),
                        SizedBox(width: 70.0,)
                      ],
                    ),


                  ],
                ),
              ),
            )),

      ),
    );
  }

  Future<bool> _onBackPressed() {
    timeDilation = 4.0;
    return showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8.0)
            ),
            title: Text('Do you want to exit this app'),
            actions: <Widget>[
              FlatButton(
                color: Colors.white,
                child: Text('No', style: TextStyle (color: Colors.blue,fontSize: 19.0),),
                onPressed: () => Navigator.pop(context, false),
              ),

              FlatButton(
                color: Colors.white,
                child: Text('Yes', style: TextStyle (color: Colors.blue,fontSize: 19.0),),
                onPressed: () => Navigator.pop(context, true),
              ),
            ],
          );
        }
    );
  }


  _firstTextfield(){
    return Flexible(
        child: TextField(
          autofocus: true,
          cursorWidth: 5.0,
          cursorRadius: Radius.circular(10.0),
          style: TextStyle(fontSize: 18.0),
          keyboardType: TextInputType.text,
          textInputAction: TextInputAction.done,
          decoration: InputDecoration(
              hintText: 'First name',
              contentPadding: EdgeInsets.all(1.0),
              hintStyle: TextStyle(fontSize: 18.0)

          ),
          onChanged: (value){

            if(value.length > 2){
              setState(() {
                _firstStatus = true;
              });
            } else {
              setState(() {
                _firstStatus = false;
              });

            }
          },
          onSubmitted: (value){
            if(_formKey.currentState.validate()){
              _formKey.currentState.save();
            }
          },
        )
    );
  }

  _lastTextfield(){
    return Flexible(
        child: TextField(
          cursorWidth: 5.0,
          cursorRadius: Radius.circular(10.0),
          style: TextStyle(fontSize: 18.0),
          autofocus: true,
          textInputAction: TextInputAction.done,
          keyboardType: TextInputType.text,
          decoration: InputDecoration(
              hintText: 'Last name',
              contentPadding: EdgeInsets.all(1.0),
              hintStyle: TextStyle(fontSize: 18.0)

          ),
          onChanged: (value){
            if(value.length >2){
              setState(() {
                _lastStatus = true;
              });
            }else {
              setState(() {
                _lastStatus = false;
              });
            }
          },
          onSubmitted: (value){
            if(_formKey.currentState.validate()){
              _formKey.currentState.save();
              if(value.length > 3){
                _navigateToAMainPage();
              }
            }

          },
        )
    );
  }

  _form(){
    return Form(
      key: _formKey,
      child: Row(
        children: <Widget>[
          _firstTextfield(),
          SizedBox(width: 20.0,),
          _lastTextfield()
        ],
      ),
    );
  }
  _emailTextField(){
    return Flexible(
      child: TextField(
        cursorWidth: 5.0,
        cursorRadius: Radius.circular(10.0),
        style: TextStyle(fontSize: 18.0),
        keyboardType: TextInputType.emailAddress,
        decoration: InputDecoration(
            contentPadding: EdgeInsets.all(1.0),
            hintText: 'Email(Optional)',
            hintStyle: TextStyle(fontSize: 18.0)
        ),
        onSubmitted: (value){
          if(value.length > 3){
            _navigateToAMainPage();
          }
        },
      ),
    );
  }

  _floatingButton(){
    return FloatingActionButton(
      onPressed: (){
        if(_firstStatus || _lastStatus){
          _navigateToAMainPage();
        }
        return null;
      },
      child: Icon(FontAwesomeIcons.arrowRight),
      backgroundColor: !_firstStatus || !_lastStatus ? Colors.grey : Colors.blue,
    );
  }



  _navigateToAMainPage(){
    Navigator.pushAndRemoveUntil(context,_pageRouter(),(route)=> false);
  }

  _pageRouter(){
    return PageRouteBuilder(
        pageBuilder: (context,animation1,animation2)=>LandingPage(),
        transitionDuration: Duration(milliseconds: 500),
        transitionsBuilder: (context, animation1,animation2, child){
          return SlideTransition(
            position: Tween<Offset>(
                begin: Offset(-1.0,0.0),end: Offset.zero).
            animate(CurvedAnimation(parent: animation1,curve: Curves.linearToEaseOut)),
            child:child,
          );
        }
    );


  }
}





