
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:mimi/form/userNames.dart';
import 'package:pin_view/pin_view.dart';





class VerificationCode extends StatefulWidget {


  @override
  _VerificationCodeState createState() => _VerificationCodeState();
}

class _VerificationCodeState extends State<VerificationCode> {

  final SmsListener smsListener = SmsListener (

      from: '6505551212', // address that the message will come from
      formatBody: (String body) {
        // incoming message type
        // from: "6505551212"
        // body: "Your verification code is: 123-456"
        // with this function, we format body to only contain
        // the pin itself

        String codeRaw = body.split(": ")[1];
        List<String> code = codeRaw.split("-");
        //return code.join();
        //341430
        return '123457';
      }
  );

  Widget _pinViewBuilder(){

    return PinView(
        style: TextStyle(fontSize: 18.0,color: Colors.black87),
        dashStyle: TextStyle(fontWeight: FontWeight.bold),
        sms: smsListener,
        enabled: false,
        autoFocusFirstField: true,
        inputDecoration: InputDecoration(
            hintText: '0'
        ),
        submit: (pin){
          _navigateToAnotherPage();
        },
        count: 6
    );
  }

  Future<bool> _onBackPressed() {
    timeDilation = 4.0;
    return showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8.0)
            ),
            title: Text('Do you want to exit this app'),
            actions: <Widget>[
              FlatButton(
                color: Colors.white,
                child: Text('No', style: TextStyle (color: Colors.blue,fontSize: 19.0),),
                onPressed: () => Navigator.pop(context, false),
              ),

              FlatButton(
                color: Colors.white,
                child: Text('Yes', style: TextStyle (color: Colors.blue,fontSize: 19.0),),
                onPressed: () => Navigator.pop(context, true),
              ),
            ],
          );
        }
    );
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: _onBackPressed,
      child: Scaffold(
        floatingActionButton: _floatingButton(),
        body: SafeArea(
            child: _formBuilder()

        ),
      ),
    );
  }

  _formBuilder(){
    return ListView(
      padding: EdgeInsets.only(left: 40.0,right: 40.0,top: 165.0),
      children: <Widget>[
        FlutterLogo(
          size: 120.0,
          colors: Colors.green,
        ),
        Padding(padding: EdgeInsets.only(top: 10.0),),
        _pinViewBuilder(),
        Padding(padding: EdgeInsets.only(top: 10.0),),
        Column(
          children: <Widget>[
            Text(
              '6 digits code will be sent ',
              style: TextStyle(color: Colors.green,fontSize: 15.0),),
            Text('to you for verification',
              style: TextStyle(color: Colors.green,fontSize: 15.0),)
          ],
        )
      ],
    );
  }
  _navigateToAnotherPage(){
    Navigator.pushAndRemoveUntil(context, _pageRouter(), (route) => false);
  }

  _pageRouter(){
    return PageRouteBuilder(
        pageBuilder: (context,animation1,animation2)=>UserNames(),
        transitionDuration: Duration(milliseconds: 100),
        transitionsBuilder: (context, animation1,animation2, child){

          Animation<Offset> offset = Tween<Offset>(
              begin: Offset(1.0, 1.0),end: Offset(0.0, 0.0)).animate(animation1);

          return SlideTransition(
            position: offset,
            child:child,
          );
        }
    );


  }
  _floatingButton(){
    return FloatingActionButton(
      onPressed: _navigateToAnotherPage,
      backgroundColor: Colors.blue,
      child: Icon(FontAwesomeIcons.arrowRight),
    );
  }

}
