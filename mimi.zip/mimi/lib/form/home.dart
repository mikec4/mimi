import 'package:country_pickers/country.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:country_pickers/country_pickers.dart';
import 'package:country_code_picker/country_code_picker.dart';



import 'package:mimi/form/verification.dart';
import 'package:mimi/mainPage/landingPage.dart';



class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> with SingleTickerProviderStateMixin {
  Color left;
  Color right;


  bool _phoneNumberStatus = false;
  bool _phoneNumberFound = false;
  bool _phoneNumberNotFound = false;

  String _phoneNumber = '';

  Future<bool> _onBackPressed() {
    timeDilation = 4.0;
    return showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8.0)
            ),
            title: Text('Do you want to exit this app'),
            actions: <Widget>[
              FlatButton(
                color: Colors.white,
                child: Text('No', style: TextStyle (color: Colors.blue,fontSize: 19.0),),
                onPressed: () => Navigator.pop(context, false),
              ),

              FlatButton(
                color: Colors.white,
                child: Text('Yes', style: TextStyle (color: Colors.blue,fontSize: 19.0),),
                onPressed: () => Navigator.pop(context, true),
              ),
            ],
          );
        }
    );
  }



  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: _onBackPressed,
      child: Scaffold(
          body: SafeArea(
            minimum: EdgeInsets.only(bottom: 1.0),
            child: SingleChildScrollView(
              //scrollDirection: Axis.vertical,
              reverse: true,
              child: _formPhoneNumber(),
            ),
          )
      ),
    );
  }


  _formPhoneNumber(){
    return ListView(
      padding: EdgeInsets.only(left: 40.0,right: 40.0,top: 165.0),
      shrinkWrap: true,
      primary: false,
      children: <Widget>[
        FlutterLogo(
          size: 120.0,
          colors: Colors.green,
        ),
        Padding(padding: EdgeInsets.only(top: 30.0),),
        _countryCodePicker(),
        Padding(padding: EdgeInsets.only(top: 10.0),),
        _textField(),
        Padding(padding: EdgeInsets.only(top: 10.0),),
        _roundedNextButton(),
        Padding(padding: EdgeInsets.only(top: 10.0),),

      ],
    );
  }


  _countryCodePicker(){
     return Row(
       children: <Widget>[
          CountryCodePicker(
            textStyle: TextStyle(fontSize: 17.0),
            onChanged: (code){},
            initialSelection: 'TZ',
            favorite: ['+255','TZ'],
            showCountryOnly: false,

          ),
       ],
     );
  }





  _textField(){
    return TextField(
      onChanged: (value){
        if(value.length != 10){
          setState(() {
            _phoneNumberStatus = false;
            _phoneNumberFound = false;
          });
          print('value is less than 10');
        }
        if(value.length == 10){
           _getPhoneNumber(value);
          print('Value on change $_phoneNumber');
        }

      },
      maxLength: 10,
      cursorWidth: 5.0,
      style: TextStyle(fontSize: 18.0),
      cursorRadius: Radius.circular(10.0),
      keyboardType: TextInputType.number,
      textInputAction: TextInputAction.done,
      decoration: InputDecoration(
          contentPadding: EdgeInsets.all(1.0),
          icon: Icon(FontAwesomeIcons.mobile,size: 30.0,),
          errorText: _validationError(),
          hintText: 'Mobile number',
          hintStyle: TextStyle(fontSize: 18.0)
      ),
    );
  }

 String _validationError(){
    if(_phoneNumberNotFound){
      return 'Mobile number not found';
    }else{
      return null;
    }

  }

   _getPhoneNumber(String value) {
     Firestore.instance.collection('phones')
         .where('myNumber',isEqualTo: value)
         .snapshots()
         .listen((onData)=>
          onData.documents.forEach((document){
            print('Data $document');
            while(document.data.length <=10) {
              if (document.exists) {
                setState(() {
                  _phoneNumber = value;
                  _phoneNumberStatus = true;
                  _phoneNumberFound = true;
                  _phoneNumberNotFound = false;
                });

              }
              break;

            }
          }));

         print('number not found');

//         setState(() {
//           _phoneNumberStatus = false;
//           _phoneNumberFound = false;
//           _phoneNumberNotFound = true;
//         });

   }

   _validatePhoneNumber(String value){
        if(value.length == 10){

        }
   }



  _roundedNextButton(){
    return Row(
      children: <Widget>[
        Flexible(
            flex: 2,
            child: Text(
              'Fill your mobile number above',
              style: TextStyle(
                  color: Colors.green,fontSize: 15.0),)
        ),
        SizedBox(width: 120.0,),
        FloatingActionButton(
          child: Icon(FontAwesomeIcons.arrowRight),
          backgroundColor: _getColors(_phoneNumberFound, _phoneNumberNotFound),
          onPressed: (){

            if(_phoneNumberFound){
              _navigateToMainPage();
            }
             else if(_phoneNumberNotFound){
              _navigateToVerificationPage();
            }

            return null;
          },
        ),
      ],
    );
  }

  Color _getColors(bool found, bool notFound){
     if(found){
       return Colors.blue;
     }
     if(notFound){
       return Colors.blue;
     }
     else {
       return Colors.grey;
     }
  }

  _navigateToVerificationPage(){
    Navigator.pushAndRemoveUntil(context,_pageRouter(),(route)=> false);
  }

  _navigateToMainPage(){
    Navigator.pushAndRemoveUntil(context,
        MaterialPageRoute(builder: (context) => LandingPage()),
            (route) => false);
  }

  _pageRouter(){
    return PageRouteBuilder(
        pageBuilder: (context,animation1,animation2)=>VerificationCode(),
        transitionDuration: Duration(milliseconds: 100),
        transitionsBuilder: (context, animation1,animation2, child){
          Animation<Offset> offset = Tween<Offset>(
              begin: Offset(1.0, 1.0),end: Offset(0.0, 0.0)).animate(animation1);
          return SlideTransition(
            position: offset,
            child:child,
          );
        }
    );
  }

}


