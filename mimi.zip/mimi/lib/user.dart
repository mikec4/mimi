class User{
  String firstName;
  String lastName;
  String phoneNumber;
  String email;

  User({this.firstName,this.lastName,this.phoneNumber,this.email});

}